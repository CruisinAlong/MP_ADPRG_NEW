#pragma once
#include "AbstractComponent.h"
#include <SFML/System/Time.hpp>

class BGMovement : public AbstractComponent {
public:
    BGMovement(std::string name);
    void perform() override;

private:
    const float SPEED = 50.f;
};
