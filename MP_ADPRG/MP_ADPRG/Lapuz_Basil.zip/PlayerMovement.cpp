#include "PlayerMovement.h"
#include "AirplanePlayer.h"
#include "PlayerInputController.h"
#include "ObjectPoolHolder.h"
#include "ProjectileObject.h"

#include <iostream>

PlayerMovement::PlayerMovement(std::string name) : AbstractComponent(name, Script), projectilePool(nullptr) {
    std::cout << "PlayerMovement [" << name << "] created." << std::endl;
}

void PlayerMovement::perform() {
    AirplanePlayer* airplanePlayer = (AirplanePlayer*)this->getOwner();
    PlayerInputController* inputController = (PlayerInputController*)(airplanePlayer->getComponentsOfType(ComponentType::Input)[0]);
    sf::Transformable* playerTransformable = airplanePlayer->getTransformable();
    if (playerTransformable == nullptr || inputController == nullptr) {
        std::cout << "PlayerMovement [" << name << "] error: playerTransformable or inputController not found." << std::endl;
        return;
    }

    sf::Vector2f offset(0.0f, 0.0f);

    if (inputController->isUp()) {
        offset.y -= this->SPEED_MULTIPLIER;
        playerTransformable->move(offset * this->deltaTime.asSeconds());
    }
    if (inputController->isDown()) {
        offset.y += this->SPEED_MULTIPLIER;
        playerTransformable->move(offset * this->deltaTime.asSeconds());
    }
    if (inputController->isRight()) {
        offset.x += this->SPEED_MULTIPLIER;
        playerTransformable->move(offset * this->deltaTime.asSeconds());
    }
    if (inputController->isLeft()) {
        offset.x -= this->SPEED_MULTIPLIER;
        playerTransformable->move(offset * this->deltaTime.asSeconds());
    }
    this->ticks += this->deltaTime.asSeconds();
    if (inputController->isFire() && this->ticks > this->BULLET_SPAWN_INTERVAL) {
        std::cout << "PlayerMovement [" << name << "] firing projectile." << std::endl;
        this->projectilePool = ObjectPoolHolder::getInstance()->getPool(ObjectPoolHolder::PROJECTILE_POOL_TAG);
        this->ticks = 0.0f;
        AbstractPoolable* projectile = this->projectilePool->requestPoolable();
        if (projectile) {
            projectile->setPosition(playerTransformable->getPosition().x, playerTransformable->getPosition().y);
            projectile->onActivate();
            std::cout << "Projectile spawned at position: " << playerTransformable->getPosition().x << ", " << playerTransformable->getPosition().y << std::endl;
        }
        else {
            std::cout << "No available projectiles in the pool." << std::endl;
        }
    }
}
