// GameScreen.cpp
#include "GameScreen.h"
#include "TextureManager.h"
#include "GameObjectManager.h"
#include <iostream>
#include <string>

GameScreen::GameScreen(std::string name) : AbstractGameObject(name), ButtonListener(), showConfirmationPopup(false) {}

void GameScreen::initialize() {
    std::cout << "GameScreen initialize called for: " << this->getName() << std::endl;

    sf::Texture* btnNormalTexture = TextureManager::getInstance()->getTexture("btn_normal");
    sf::Texture* btnPressedTexture = TextureManager::getInstance()->getTexture("btn_pressed");


    BGObject* bgObject = new BGObject("bgObject");
    GameObjectManager::getInstance()->addObject(bgObject);



    std::cout << "Creating PlaneObject" << std::endl;
    planeObject = new AirplanePlayer("PlaneObject");
    GameObjectManager::getInstance()->addObject(planeObject);

    std::cout << "Creating AirSupport_1" << std::endl;
    support1 = new AirplaneSupport("AirSupport_1");
    planeObject->attachChild(support1);
    support1->setPosition(50, 100);

    std::cout << "Creating AirSupport_2" << std::endl;
    support2 = new AirplaneSupport("AirSupport_2");
    planeObject->attachChild(support2);
    support2->setPosition(-50, 100);

    srand(time(nullptr));
    std::cout << "Creating EnemiesManager" << std::endl;
    EmptyGameObject* enemiesManager = new EmptyGameObject("EnemiesManager");
    EnemySwarmHandler* swarmHandler = new EnemySwarmHandler(20, "SwarmHandler", enemiesManager);
    enemiesManager->attachComponent(swarmHandler);
    GameObjectManager::getInstance()->addObject(enemiesManager);

    std::cout << "Creating enemyPool" << std::endl;
    enemyPool = new GameObjectPool(ObjectPoolHolder::PROJECTILE_POOL_TAG, new ProjectileObject("projectile"), 10, nullptr);
    enemyPool->initialize();
    ObjectPoolHolder::getInstance()->registerObjectPool(enemyPool);



    std::cout << "Creating HUD" << std::endl;
    hud = new HUD("HUD");
    GameObjectManager::getInstance()->addObject(hud);

    std::cout << "Creating ConfirmationText" << std::endl;
    confirmationText = new UIText("ConfirmationText");
    confirmationText->setText("Are you sure you want to go back to the menu?");
    confirmationText->setPosition(320.0f, 200.0f);
    confirmationText->setEnabled(false);
    GameObjectManager::getInstance()->addObject(confirmationText);

    std::cout << "Creating YesButton" << std::endl;
    yesButton = new UIButton("YesButton", btnNormalTexture, btnPressedTexture);
    yesButton->setButtonListener(this);
    yesButton->setPosition(270.0f, 250.0f);
    yesButton->setEnabled(false);
    GameObjectManager::getInstance()->addObject(yesButton);

    std::cout << "Creating NoButton" << std::endl;
    noButton = new UIButton("NoButton", btnNormalTexture, btnPressedTexture);
    noButton->setButtonListener(this);
    noButton->setPosition(370.0f, 250.0f);
    noButton->setEnabled(false);
    GameObjectManager::getInstance()->addObject(noButton);

    std::cout << "Creating YesButtonText" << std::endl;
    yesButtonText = new UIText("YesButtonText");
    yesButtonText->setText("Yes");
    yesButtonText->setPosition(yesButton->getTransformable()->getPosition().x, yesButton->getTransformable()->getPosition().y);
    yesButtonText->setEnabled(false);
    GameObjectManager::getInstance()->addObject(yesButtonText);

    std::cout << "Creating NoButtonText" << std::endl;
    noButtonText = new UIText("NoButtonText");
    noButtonText->setText("No");
    noButtonText->setPosition(noButton->getTransformable()->getPosition().x, noButton->getTransformable()->getPosition().y);
    noButtonText->setEnabled(false);
    GameObjectManager::getInstance()->addObject(noButtonText);

    MainMenuScreen* mainMenu = new MainMenuScreen("MainMenu");
    GameObjectManager::getInstance()->addObject(mainMenu);
    mainMenu->setEnabled(false);

    std::cout << "GameScreen initialization complete" << std::endl;
}

void GameScreen::onButtonClick(UIButton* button) {
    std::cout << button->getName() << " clicked" << std::endl;
    if (button->getName() == "QuitButton") {
        showConfirmationPopup = true;
        confirmationText->setEnabled(true);
        yesButton->setEnabled(true);
        noButton->setEnabled(true);
        yesButtonText->setEnabled(true);
        noButtonText->setEnabled(true);
    }
    else if (button->getName() == "YesButton") {
        SceneManager::getInstance()->loadScene("MainMenuScene");
    }
    else if (button->getName() == "NoButton") {
        showConfirmationPopup = false;
        confirmationText->setEnabled(false);
        yesButton->setEnabled(false);
        noButton->setEnabled(false);
        yesButtonText->setEnabled(false);
        noButtonText->setEnabled(false);
    }
}

void GameScreen::onButtonReleased(UIButton* button) {
    std::cout << button->getName() << " released" << std::endl;
}

