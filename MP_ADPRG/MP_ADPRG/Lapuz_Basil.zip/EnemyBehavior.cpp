#include "EnemyBehavior.h"
#include "AbstractGameObject.h"
#include "Game.h"
#include <SFML/Graphics.hpp>

EnemyBehavior::EnemyBehavior(std::string name) : AbstractComponent(name, Script) {
	this->reset();
}

void EnemyBehavior::perform() {
	this->ticks += this->deltaTime.asSeconds();
	sf::Transformable* transformable = this->getOwner()->getTransformable();

	if (this->ticks > this->forwardDuration && this->movementType != Side) {
		int counter = (this->movementType + 1) % EnemyMovementType::Side + 1;
		this->movementType = (EnemyMovementType)counter;
	}
	if (this->movementType == Forward) {
		transformable->move(0, this->deltaTime.asSeconds() * SPEED_MULTIPLIER);
	}
	else if (this->movementType == SlowForward) {
		transformable->move(0, this->deltaTime.asSeconds() * (SPEED_MULTIPLIER / 2.0f)	);
	}
	else if (this->movementType == Side) {
		if (transformable->getPosition().x > Game::WINDOW_WIDTH / 2) {
			transformable->move(this->deltaTime.asSeconds() * SPEED_MULTIPLIER * 1.5, 0);
		}
		else {
			transformable->move(-this->deltaTime.asSeconds() * SPEED_MULTIPLIER * 1.5, 0);
		}
	}
}

void EnemyBehavior::configure(float delay) {
	this->delay = delay;
}

void EnemyBehavior::reset() {
	this->ticks = 0.0f;
	this->movementType = Forward;
	this->forwardDuration = (rand() % 3) + 1.0f;
}