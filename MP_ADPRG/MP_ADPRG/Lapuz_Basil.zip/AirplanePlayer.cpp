#include "AirplanePlayer.h"
#include <iostream>
#include "TextureManager.h"
#include "Game.h"

AirplanePlayer::AirplanePlayer(std::string name) : AbstractGameObject(name)
{
}

void AirplanePlayer::initialize()
{
	std::cout << "AirplanePlayer initialized" << std::endl;
	this->sprite = new sf::Sprite();
	this->sprite->setTexture(*TextureManager::getInstance()->getTexture("eagle"));
	sf::Vector2u textureSize = sprite->getTexture()->getSize();
	this->sprite->setOrigin(textureSize.x / 2, textureSize.y / 2);
	this->transformable.setPosition(Game::WINDOW_WIDTH / 2, Game::WINDOW_HEIGHT / 2);

	PlayerInputController* inputController = new PlayerInputController("MyPlayerInput");
	this->attachComponent(inputController);

	PlayerMovement* movement = new PlayerMovement("MyMovement");
	this->attachComponent(movement);

	Renderer* renderer = new Renderer("PlayerSprite");
	renderer->assignDrawable(sprite);
	this->attachComponent(renderer);
}

void AirplanePlayer::processInputs(sf::Event event) {
	AbstractGameObject::processInputs(event);
}

void AirplanePlayer::update(sf::Time deltaTime) {
	AbstractGameObject::update(deltaTime); 
}
