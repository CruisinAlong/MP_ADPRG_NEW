#include "BGMovement.h"
#include "BGObject.h"
#include <iostream>

BGMovement::BGMovement(std::string name) : AbstractComponent(name, Script) {
    // Constructor implementation
}

void BGMovement::perform() {
    BGObject* bgObject = (BGObject*)this->getOwner();
    sf::Transformable* bgTransformable = bgObject->getTransformable();
    if (bgTransformable == nullptr) {
        std::cout << "bgTransformable not found" << std::endl;
        return;
    }

    sf::Vector2f offset(0.0f, SPEED * this->deltaTime.asSeconds());
    bgTransformable->move(offset);
}
