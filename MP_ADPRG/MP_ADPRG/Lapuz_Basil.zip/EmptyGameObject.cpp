#include "EmptyGameObject.h"

EmptyGameObject::EmptyGameObject(std::string name) : AbstractGameObject(name) {

}

void EmptyGameObject::initialize() {

}